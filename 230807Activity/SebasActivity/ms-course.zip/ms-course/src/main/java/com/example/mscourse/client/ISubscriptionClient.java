package com.example.mscourse.client;

import com.example.mscourse.config.ConfiguracionBalanceador;
import org.springframework.cloud.loadbalancer.annotation.LoadBalancerClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("ms-subscription")
@LoadBalancerClient(name= "ms-subscription", configuration = ConfiguracionBalanceador.class )
public interface ISubscriptionClient {

    @GetMapping("/subscription/find")
    public String find();

}
